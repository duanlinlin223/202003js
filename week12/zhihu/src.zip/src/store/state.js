export default {
    hotlist:[]
}