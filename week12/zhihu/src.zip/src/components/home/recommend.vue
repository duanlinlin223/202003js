<template>
  <div class="recommend">
      推荐
  </div>
</template>

<script>
export default {
  name: 'recommend',
  data() { 
    return {

    }
  }
 }
</script>

<style lang="less" scoped>
  .recommend{

  }
</style>