export function changeDepartmentList(state, option) {
    state.departmentList = option
}
export function changeJob(state, option) {
    state.jobList = option;
}
export function changeUserList(state, option) {
    state.userList = option;
}