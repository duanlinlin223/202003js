<template>
    <el-table
        :data="tableData"
        border
        :header-cell-style="{background:'#eef1f6',color:'#606266'}"
        style="width: 100%"
    >
        <el-table-column prop="id" label="编号" width="180"></el-table-column>
        <el-table-column prop="name" label="职务" width="180"></el-table-column>
        <el-table-column prop="desc" label="描述"></el-table-column>
        <el-table-column prop="power" label="权限"></el-table-column>
        <el-table-column prop="address" label="操作">
            <template slot-scope="scope">
                <el-button size="mini" @click="handleEdit(scope.row)">编辑</el-button>
                <el-button size="mini" type="danger">删除</el-button>
                <!-- <el-button size="mini" type="primary">重置</el-button> -->
            </template>
        </el-table-column>
    </el-table>
</template>

<script>
export default {
    data() {
        return {};
    },
    created() {
        //console.log(this.tableData);
        this.$store.dispatch("changeJobList");
    },
    methods: {
        handleEdit(row) {
            //console.log(row.power);
            this.$router.push({
                path: "/org/addJob",
                query: { id: row.id, power: row.power }
            });
        }
    },
    computed: {
        tableData() {
            return this.$store.state.jobList;
        }
    }
};
</script>
<style lang='less' scoped>
</style>