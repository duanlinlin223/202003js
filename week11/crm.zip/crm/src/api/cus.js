import http from "./http.js";

//获取全部客户列表
export function allCustomer(option) {
    return http.get("/customer/list", {
        params: option,
    });
}

//删除客户列表
export function deleteCus(id) {
    return http.get("/customer/delete", {
        params: {
            customerId: id,
        },
    });
}

//新增客户列表
export function addCus(option) {
    return http.post("/customer/add", option);
}

//修改客户列表
export function updateCus(option) {
    return http.post("/customer/update", option);
}