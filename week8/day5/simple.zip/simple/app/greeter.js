
module.exports=function(){
    let ele = document.createElement('div');
    
    ele.innerHTML = 'zhufengpeixun'
    return ele
}