import React from "react";
class TodoFooter extends React.Component{
    constructor(){
        super();
    }
    render(){
        return <div>TodoFooter</div>
    }
}
export default TodoFooter;