import React from "react";
import {connect} from "react-redux";
class TodoBody extends React.Component{
    constructor(){
        super();
    }
    render(){
        // li应该利用store中的数据渲染出来
        return <div>
            <ul className="list-group">
                {this.props.todos.map((item,index)=>{
                    return <li className="list-group-item" key={index}>
                        <input type="checkBox" checked={item.isSelected} onChange={()=>{}}></input>
                        {item.val}
                        <button className="btn-danger btn-xs pull-right btn">×</button>
                    </li>
                })}
            </ul>
        </div>
    }
}
export default connect(state=>({...state.todo}))(TodoBody);