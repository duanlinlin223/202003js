import * as Types from "../action-types";
// 导出一个对象
export default {
    addTodo(val){
        return {type:Types.ADD_TODO,val}
    }
}
